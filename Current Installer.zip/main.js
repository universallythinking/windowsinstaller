const electron = require('electron')
// Module to control application life.
const app = electron.app
// Module to create native browser window.
const BrowserWindow = electron.BrowserWindow

const path = require('path')
const url = require('url')
/**
 * This is an example of a basic node.js script that performs
 * the Authorization Code oAuth2 flow to authenticate against
 * the Spotify Accounts.
 *
 * For more information, read
 * https://developer.spotify.com/web-api/authorization-guide/#authorization_code_flow
 */
/**
 * This is an example of a basic node.js script that performs
 * the Authorization Code oAuth2 flow to authenticate against
 * the Spotify Accounts.
 *
 * For more information, read
 * https://developer.spotify.com/web-api/authorization-guide/#authorization_code_flow
 */
var express = require('express'); // Express web server framework
var request = require('request'); // "Request" library
var querystring = require('querystring');
var cookieParser = require('cookie-parser');
var Repeat = require('repeat');
ii = 3;
if (ii === 1) {
    var client_id = '71d18cb9b32c480d951eed41512df8fc'; // Your client id
    var client_secret = '2e89cb3f772345279ae54fa417cc7457'; // Your secret
    var redirect_uri = 'http://app2.jkbx.us/callback/'; // Your redirect uri
}
else if (ii === 2) {
    var client_id = "23fda62574464d50be2ecfd8540353b5"; // Your client id
    var client_secret = "44c1395c8390426d8b6b3f938f29af58";
    var redirect_uri = 'http://spartify.herokuapp2.com/callback/'; // Your redirect uri
}
else if (ii === 3) {
    var client_id = '71d18cb9b32c480d951eed41512df8fc'; // Your client id
    var client_secret = '2e89cb3f772345279ae54fa417cc7457'; // Your secret
    var redirect_uri = 'http://localhost:8080/callback/'; // Your redirect uri
}

var generateRandomString = function (length) {
    var text = '';
    var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (var i = 0; i < length; i++) {
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
};
var nodeSpotifyWebHelper = require('node-spotify-webhelper');
var spotify = new nodeSpotifyWebHelper.SpotifyWebHelper();

// get the name of the song which is currently playing

var stateKey = 'spotify_auth_state';

var app2 = express();

app2.use(express.static(__dirname + '/public'))
    .use(cookieParser());

app2.get('/login', function (req, res) {

    var state = generateRandomString(16);
    res.cookie(stateKey, state);

    // your app2lication requests authorization
    var scope = 'user-read-private user-read-email';
    res.redirect('https://accounts.spotify.com/authorize?' +
        querystring.stringify({
            response_type: 'code',
            client_id: client_id,
            scope: scope,
            redirect_uri: redirect_uri,
            state: state
        }));
});

app2.get('/choose-a-playlist', function (req, res) {
    res.redirect('/playlists.html');
});
app2.get('/details', function (req, res) {
    res.redirect('/welcome.html');
});
app2.get('/error', function (req, res) {
    res.redirect('/error.html');
});
app2.get('/songUpdate', function (req, res) {
    var song = req.query.track;
    var artist = req.query.artist;
    var user = req.query.user;
});
app2.get('/callback', function (req, res) {

    // your app2lication requests refresh and access tokens
    // after checking the state parameter

    var code = req.query.code || null;
    var state = req.query.state || null;
    var storedState = req.cookies ? req.cookies[stateKey] : null;

    if (state === null || state !== storedState) {
        res.redirect('/#' +
            querystring.stringify({
                error: 'state_mismatch'
            }));
    } else {
        res.clearCookie(stateKey);
        var authOptions = {
            url: 'https://accounts.spotify.com/api/token',
            form: {
                code: code,
                redirect_uri: redirect_uri,
                grant_type: 'authorization_code'
            },
            headers: {
                'Authorization': 'Basic ' + (new Buffer(client_id + ':' + client_secret).toString('base64'))
            },
            json: true
        };

        request.post(authOptions, function (error, response, body) {
            if (!error && response.statusCode === 200) {

                var access_token = body.access_token,
                    refresh_token = body.refresh_token;
                // console.log(body);
                var options = {
                    url: 'https://api.spotify.com/v1/me',
                    headers: { 'Authorization': 'Bearer ' + access_token },
                    json: true
                };

                // use the access token to access the Spotify Web API
                request.get(options, function (error, response, body) {
                    console.log(body);
                    userName = body.id;
                });

                // we can also pass the token to the browser to make requests from there
                res.redirect('/#' +
                    querystring.stringify({
                        access_token: access_token,
                        refresh_token: refresh_token
                    }));
            } else {
                res.redirect('/#' +
                    querystring.stringify({
                        error: 'invalid_token'
                    }));
            }
        });
    }
});
var userName = "";
app2.get('/refresh_token', function (req, res) {

    //requesting access token from refresh token
    // var refresh_token = req.body.refresh_token;
    var refresh_token = req.query.refresh_token;
    var authOptions = {
        url: 'https://accounts.spotify.com/api/token',
        headers: { 'Authorization': 'Basic ' + (new Buffer(client_id + ':' + client_secret).toString('base64')) },
        form: {
            grant_type: 'refresh_token',
            refresh_token: refresh_token
        },
        json: true
    };

    request.post(authOptions, function (error, response, body) {
        if (!error && response.statusCode === 200) {
            var access_token = body.access_token;
            res.send({
                'access_token': access_token
            });
        }
        else {
            res.send("Failed to update token");
        }
    });
});
app2.get('/SorryCharlie', function (req, res) {
    res.redirect('http://jkbx.us/');
});
app2.get('/error', function (req, res) {
    res.redirect('/error.html');
});
var databaseURL = 'postgres://yotnkoupklgnce:PEI_Vz3Jnz8qebuxiSafxNHcrj@ec2-54-235-95-188.compute-1.amazonaws.com:5432/d6480t5vkn701i';
var pg = require('pg');
pg.defaults.ssl = true;

var bodyParser = require('body-parser');

app2.use(bodyParser.json());

app2.use(bodyParser.urlencoded({
    extended: false
}));
var config = {
    user: 'yotnkoupklgnce', //env var: PGUSER
    database: 'd6480t5vkn701i', //env var: PGDATABASE
    password: 'PEI_Vz3Jnz8qebuxiSafxNHcrj', //env var: PGPASSWORD
    host: 'ec2-54-235-95-188.compute-1.amazonaws.com', // Server hosting the postgres database
    port: 5432, //env var: PGPORT
    max: 2, // max number of clients in the pool
    idleTimeoutMillis: 1, // how long a client is allowed to remain idle before being closed
};
var config2 = {
    user: 'yotnkoupklgnce', //env var: PGUSER
    database: 'd6480t5vkn701i', //env var: PGDATABASE
    password: 'PEI_Vz3Jnz8qebuxiSafxNHcrj', //env var: PGPASSWORD
    host: 'ec2-54-235-95-188.compute-1.amazonaws.com', // Server hosting the postgres database
    port: 5432, //env var: PGPORT
    max: 1, // max number of clients in the pool
    idleTimeoutMillis: 1, // how long a client is allowed to remain idle before being closed
};


//this initializes a connection pool
//it will keep idle connections open for 30 seconds
//and set a limit of maximum 10 idle clients
var pool = new pg.Pool(config);
var pool2 = new pg.Pool(config2);

app2.post('/votes', function (request, response) {
    try {
        pool.connect(function (err, client, done) {
            if (err) { throw err; }
            if (request.body.userName) {
                client
                    .query("select songname from songvotes where userid in ($1)", [request.body.userName], function (err, result) {
                        done(err);
                        if (result.rows.length > 0) {
                            results = {};
                            results["songs"] = JSON.stringify(result.rows[0].songname);
                            response.send(results);
                            //client.end();
                        }
                        else {
                            response.send("FAILURE 214");
                            //client.end();
                        }
                        setTimeout(function() { client.end(); }, 6500);
                    });
            }
        });
    }
    catch (exception) {
        console.log(exception);
    }
    //pg.end();
});

app2.post('/checkPassword', function (request, response) {
    pool.connect(function (err, client, done) {
        if (request.body.password) {
            client
                .query("select distinct lastfm from users where lastfm in ($1)", [request.body.password], function (err, result) {
                    done(err);
                    if (result.rows.length <= 0) {
                        results = {};
                        results["success"] = JSON.stringify("SUCCESS");
                        response.send(results);
                        //client.end();
                    }
                    else if (result.rows.length > 0) {
                        results = {};
                        results["failure"] = JSON.stringify("FAIL");
                        response.send(results);
                        //client.end();
                    }
                    else {
                        response.send("FAILURE 245");
                        //client.end();
                    }
                    setTimeout(function() { client.end(); }, 6500);
                });
        }
    });
    //pg.end();
});

var sec = 1;
app2.post('/play', function (request, response) {
  console.log(request.body.url);
    var resObj;
    spotify.play(request.body.url, function (err, res) {
        if (err) {
            console.info(err);
        }
        else {
            nowPlaying2();
            console.info(res);
        }
    });
    response.send("SUCCESS");
    console.info(resObj); return;
    });
app2.post('/123', function (request, response) {
    var nowPlaying3 = function () {
        spotify.getStatus(function (err, res) {
            if (err) {
                return console.error(err);
            }
            sec = res.track.length - res.playing_position;
            if (currentSong != res.track.track_resource.name) {
                nowPlaying();
            }
            console.info('currently playing:',
                res.track.artist_resource.name, '-',
                res.track.track_resource.name);
            var res1 = {};
            res1["songs"] = JSON.stringify(res.track.track_resource.name);
            res1["artist"] = JSON.stringify(res.track.artist_resource.name);
            res1["seconds"] = JSON.stringify(sec);
            response.send(res1);
        });
    }
    nowPlaying3();
});

var currentSong = "";
var currentArtist = "";
var seconds = 1;
var nowPlaying = function () {
    console.log("UN =" + userName);
    spotify.getStatus(function (err, res) {
        if (err) {
            return console.error(err);
        }
        currentSong = res.track.track_resource.name;
        currentArtist = res.track.artist_resource.name;
        console.info('now playing:',
            currentArtist, '-',
            currentSong);
        songUpdate(currentSong, currentArtist, userName);
    });
    console.log(userName);
};
nowPlaying();
var nowPlaying2 = function () {
    spotify.getStatus(function (err, res) {
        console.info(seconds);
        if (err) {
            return console.error(err);
        }
        if (currentSong != res.track.track_resource.name) {
            nowPlaying();
        }
        console.info('currently playing:',
            res.track.artist_resource.name, '-',
            res.track.track_resource.name);
    });
};
var songUpdate = function (songTitle, artist, userName) {
    console.log(songTitle, artist, userName);
    pool.connect(function (err, client, done) {
        client
            .query("update songupdate set artist = $1 where userid in ($2)", [artist, userName]);
        client
            .query("update songupdate set songname = $1 where userid in ($2)", [songTitle, userName], function (err, result) {
                done(err);
                if (err) { throw err; }
                setTimeout(function() { client.end(); }, 6500);
            });
    });
    //pg.end();
}
app2.post('/songRefresh', function (request, response) {
    pool.connect(function (err, client, done) {
        if (request.body.lastFM) {
            client
                .query("select * from songupdate where userid in ($1)", [request.body.lastFM], function (err, result) {
                    done(err);
                    if (result.rows.length > 0) {
                        console.log(result.rows);
                        results = {};
                        results["songs"] = JSON.stringify(result.rows[0].songname);
                        results["playlist"] = JSON.stringify(result.rows[0].playlist);
                        results["artist"] = JSON.stringify(result.rows[0].artist);
                        response.send(results);
                        //client.end();
                    }
                    else {
                        results = {};
                        results["songs"] = JSON.stringify(result);
                        results["playlist"] = JSON.stringify(result);
                        results["artist"] = JSON.stringify(result);
                        response.send(results);
                        //client.end();
                    }
                    setTimeout(function() { client.end(); }, 6500);
                });
        }

    });
    //pg.end();
});

app2.post('/songUpdater', function (request, response) {
  pool.connect(function (err, client, done) {
            if (err) { response.send("Error"); if (client){client.end();} throw err; }
                    if (request.body.songTitle) {
                            client
                                .query("update songupdate set artist = $1 where userid in ($2)", [request.body.artist, request.body.userName]);
                            client
                                .query("update songupdate set songname = $1 where userid in ($2)", [request.body.songTitle, request.body.userName])
                                .on('end', function (finalres) {
                                    if (err) { if (client){client.end();} throw err; }
                                    else if (request.body.songTitle) {
                                        console.log("CURL");
                                        console.log(request.body.songTitle);
                                        res1 = {};
                                        res1["songs"] = "SUCCESS";
                                        response.send(res1);
                                        if (client){client.end();}
                                    }
                                    else {
                                        if (client){client.end();}
                                    }
                                    setTimeout(function() { client.end(); }, 6500);
                              });
}
});
});

app2.post('/upVote', function (request, response) {
    pool.connect(function (err, client, done) {
        if (request.body.userName && request.body.party && request.body.song) {
            client
                .query("UPDATE songvotes set songname = (songname || ($1) || ($2)) where userid in ($3)", [",  +", request.body.song, request.body.userName], function (err, result) {
                    done(err);
            });
            client
                .query("select songname from songvotes where userid in ($1)", [request.body.userName], function (err, result) {
                    done(err);
                    if (result.rows.length > 0) {
                        var results = {};
                        results["songs"] = JSON.stringify(result.rows[0].songname);
                        response.send(results);
                        //client.end();
                    }
                    else {
                        response.send("Error");
                        //client.end();
                    }
                    setTimeout(function() { client.end(); }, 6500);
                });
        }
    });
    //pg.end();
});

app2.post('/downVote', function (request, response) {
    pool.connect(function (err, client, done) {
        if (request.body.userName && request.body.party && request.body.song) {
            client
                .query("UPDATE songvotes set songname = (songname || ($1) || ($2)) where userid in ($3)", [",  -", request.body.song, request.body.userName], function (err, result) {
                    done(err);
                    client
                        .query("select songname from songvotes where userid in ($1)", [request.body.userName], function (err, result) {
                            done(err);
                            if (result.rows.length > 0) {
                                var results = {};
                                results["songs"] = JSON.stringify(result.rows[0].songname);
                                response.send(results);
                                //client.end();
                            }
                            else {
                                response.send("Error");
                                //client.end();
                            }
                            setTimeout(function() { client.end(); }, 6500);
                        });
                });
        }
    });
    //pg.end();
});

app2.post('/clearVotes', function (request, response) {
    pool.connect(function (err, client, done) {
        if (request.body.userName) {
            client
                .query("UPDATE songvotes set songname = ($1) where userid in ($2)", ["null", request.body.userName], function (err, result) {
                    done(err);
                    var object = {};
                    object["data"] = result.rows;
                    response.send(object);
                    //client.end();
                    setTimeout(function() { client.end(); }, 6500);
                });
        }
    });
    //pg.end();
});

app2.post('/', function (request, response) {
    console.log(request);
    pool2.connect(function (err, client, done) {
        done(err);
        if (request.body.party) {
            client
                .query("select distinct * from users where party in ($1)", [request.body.party.toUpperCase()], function (err, result) {
                    if (result.rows.length > 0 && result.rows[0].username != request.body.username) {
                        var results = {};
                        results["invalid"] = "Enter a different Party Password.";
                        console.log(result.rows[0] + "HERE");
                        response.send(results);
                        //client.end();
                    }
                    else if (request.body.username) {
                        client
                            .query("select * from users where username in ($1)", [request.body.username], function (err, result) {
                                if (request.body.party && result.rows.length > 0 && request.body.playlist && request.body.access_token && request.body.lastFM && request.body.password && !request.body.search && request.body.refresh_token) {
                                    client
                                        .query("UPDATE songvotes SET partyname = $1 where userid in ($2)", [request.body.party, request.body.username]);
                                        client
                                            .query("UPDATE songupdate SET username = $1 where userid in ($2)", [request.body.lastFM, request.body.username]);
                                            client
                                                .query("UPDATE songupdate SET playlist = $1 where userid in ($2)", [request.body.playlist, request.body.username]);
                                            client
                                        .query("UPDATE users SET lastfm = $1 where username in ($2)", [request.body.lastFM, request.body.username]);
                                    client
                                        .query("UPDATE users SET superpowers = $1 where username in ($2)", [request.body.password, request.body.username]);
                                    client
                                        .query("UPDATE users SET explicit = $1 where username in ($2)", [request.body.explicit, request.body.username]);
                                    client
                                        .query("UPDATE users SET access_token = $1 where username in ($2)", [request.body.access_token, request.body.username]);
                                    client
                                        .query("UPDATE users SET playlist = $1 where username in ($2)", [request.body.playlist, request.body.username]);
                                    client
                                        .query("UPDATE users SET refresh_token = $1 where username in ($2)", [request.body.refresh_token, request.body.username]);
                                    client
                                        .query("UPDATE users SET party = $1 where username in ($2)", [request.body.party.toUpperCase(), request.body.username], function (err, result) {
                                            done(err);
                                            var results = "Hello fellow coders!!";
                                            response.send(results);
                                            //client.end();
                                        });
                                }
                                else if (request.body.party && request.body.username && request.body.playlist && request.body.lastFM && request.body.password && !request.body.search && request.body.refresh_token) {
                                    client
                                        .query("INSERT INTO songupdate values($1, $2, $3, $4)", [request.body.lastFM, "firstEntry", "secondEntry", request.body.username]);
                                    client
                                        .query("INSERT INTO songvotes values($1, $2, $3)", ["firstEntry", request.body.username, request.body.party]);
                                    client
                                        .query("INSERT INTO users values($1, $2, $3, $4, $5, $6, $7, $8)", [request.body.party.toUpperCase(), request.body.access_token, request.body.lastFM, request.body.username, request.body.playlist, request.body.explicit, request.body.password, request.body.refresh_token], function (err, result) {
                                            done(err);
                                            var results = "Hello fellow coders!!";
                                            response.send(results);
                                            //client.end();
                                        });
                                }
                            });
                    }
                    setTimeout(function() { client.end(); }, 6500);
                });
        }
        else if (request.body.search) {
            client
                .query("select * from public.users where party in ($1)", [request.body.search.toUpperCase()], function (err, result) {
                    done(err);
                    if (result.rows[0]) {
                        var results = {};
                        results["password"] = JSON.stringify(result.rows[0].superpowers);
                        results["access_token"] = JSON.stringify(result.rows[0].access_token);
                        results["lastFM"] = JSON.stringify(result.rows[0].lastfm);
                        results["partyID"] = JSON.stringify(result.rows[0].party);
                        results["username"] = JSON.stringify(result.rows[0].username);
                        results["playlist"] = JSON.stringify(result.rows[0].playlist);
                        results["explicit"] = JSON.stringify(result.rows[0].explicit);
                        results["refresh_token"] = JSON.stringify(result.rows[0].refresh_token);
                        response.send(results);
                        //client.end();
                        //pg.end();
                    }
                    else {
                        response.send("No Matches");
                        //client.end();
                        //pg.end();
                    }
                    setTimeout(function() { client.end(); }, 6500);
                });
        }

    });
    //pg.end();
});

pool.on('error', function (err, client, done) {
    // if an error is encountered by a client while it sits idle in the pool
    // the pool itself will emit an error event with both the error and
    // the client which emitted the original error
    // this is a rare occurrence but can happen if there is a network partition
    // between your application and the database, the database restarts, etc.
    // and so you might want to handle it and at least log it out
    console.error('idle client error', err.message, err.stack)
});
setInterval(function () {
    nowPlaying2();
}, 1500);

if (ii === 1) {
    console.log('Listening on 5000');
    app2.listen(process.env.PORT || 5000)
}
else if (ii === 2) {
    console.log('Listening on 5000');
    app2.listen(process.env.PORT || 5000)
}
else if (ii === 3) {
    console.log('Listening on 8080');
    app2.listen(process.env.PORT || 8080)
}

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow
var ses;
function createWindow () {
  // Create the browser window.
  mainWindow = new BrowserWindow({width: 900, height: 700})

  // and load the index.html of the app.
  mainWindow.loadURL(url.format({
    pathname: path.join(__dirname, 'public/index.html'),
    protocol: 'file:',
    slashes: true
  }))
  ses = mainWindow.webContents.session;

  // Open the DevTools.
  //mainWindow.webContents.openDevTools()

  // Emitted when the window is closed.
  mainWindow.on('closed', function () {
    ses.clearStorageData()
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null
  })
}
// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow)
// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On OS X it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') {
    ses.clearStorageData()
    app.quit()
  }
})
process.on('uncaughtException', function (e) {
    console.log("caught from process" + e);
});

app.on('activate', function () {
  // On OS X it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) {
    createWindow()
  }
})
