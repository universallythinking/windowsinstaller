$(document).ready(function () {
if (localStorage.lastFM && localStorage.explicit && localStorage.Snapster && $("#results").children("header")) {
//setInterval(function() {
//  votes();
//}, 1000);
}
});
