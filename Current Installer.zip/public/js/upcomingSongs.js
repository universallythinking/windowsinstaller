$(document).ready(function () {
  if (!document.hidden) {
    if (!localStorage.votedArray) {
	    localStorage.setItem("votedArray", " ");
    }
    else if (localStorage.voteTotals) {
	    localStorage.setItem("votedArray", localStorage.voteTotals);
	 }
    $('#results').empty;
    var playlists = [];
    var currentTracks = [];
    var obj = {};
    var temporaryTrack;
    localStorage["totalSongs"] = 0;
    localStorage["currentlyPlayingWC"] = "";
    localStorage["currentlyPlaying"] = "";
    localStorage["currentTrack"] = 0;
    localStorage["offsetNumber"] = 0;
    var partyPlaylist = 0;
    $('#infoHeader').empty();
    $('#infoHeader').append("MENU");
    $('#nameify').empty();
   if (localStorage.party) { $('#nameify').append("#" + localStorage.party.toUpperCase()); }
window.loading = function () {
setInterval(function() {
if ($("#results").children("header").length > 2) {
         document.getElementById('load').style.visibility="hidden";
         document.getElementById('main').style.visibility="visible";
       }
       else {
         nextSongs();
       }
 }, 1000);
}
loading();
 window.resetVotes = function () {
    localStorage.votedArray = "";
	  if (localStorage.host) {
    localStorage.setItem("STOP", "true");
    var object = {};
    object["userName"] = localStorage.userID;
     $.ajax({
         async: true,
         type: "POST",
         url: "http://localhost:8080/clearVotes",
         dataType: "json",
         data: object,
         success: function (clearedData) {
           localStorage.STOP = "false";
           localStorage.votedArray = "";
         }
    });
	  }
}
setTimeout(function() {
  nextSongs();
}, 5000);
setInterval(function () {
 if (localStorage.currentTrack % 5 == 0) {
   resetVotes();
 }
}, 90000);
   window.nextSongs = function () {
          var albumArtArray = [];
            window.CT = function () {
            if (localStorage["userID"] && localStorage["Snapster"] && localStorage["explicit"]) {
                        $.ajax({
                            async: false,
                            type: "GET",
                            url: "https://api.spotify.com/v1/users/" + localStorage['userID'] + "/playlists/" + localStorage['Snapster'] + "/tracks",
                            headers: { 'Authorization': 'Bearer ' + access_token },
                            dataType: "json",
                            data: "formdata",
                            success: function (trackData) {
                              currentTracks = [];
                              currentTracks2 = [];
                                for (var i = 0; i < trackData.items.length; i++) {
                                  currentTracks[i] = trackData.items[i].track.name.toUpperCase();
                                  currentTracks2[i] = trackData.items[i].track.name;
                                }
                                localStorage["CT"] = currentTracks.toString().toUpperCase();
                                localStorage["CT1"] = currentTracks2.toString();
                                localStorage["totalSongs"] = currentTracks.length;
                                if (currentTracks.indexOf(localStorage["currentlyPlayingWC"]) != -1) {
                                    localStorage.currentTrack = currentTracks.indexOf(localStorage["currentlyPlayingWC"]);
                                }
                                else {
                                    temporaryTrack = localStorage["currentlyPlayingWC"].substr(0, 7);
                                    for (var i = 0; i < currentTracks.length; i++) {
                                        if (currentTracks[i].substr(0, 7).indexOf(temporaryTrack) > -1) {
                                            localStorage["currentTrack"] = currentTracks.indexOf(currentTracks[i]);
                                        }
                                    }
                                }
                                for (var i = 0; i < currentTracks.length; i++) {
                                    if (localStorage["currentTrack"] >= 4) {
                                        localStorage["offsetNumber"] = localStorage["currentTrack"];
                                    }
                                    else {
                                        localStorage["offsetNumber"] = localStorage["currentTrack"];
                                    }
                                    currentTracks = [];
                                }
                            }
                        });
                    }
        }
                if (localStorage["lastFM"]) {
                  CT();
                    $("#results").css("padding-top", "298px !important");
                    if (document.getElementById('filename').value == "Join a Party..." || document.getElementById('filename').value == "") {
                        if ((document.getElementById('filename').value == "Join a Party..." || document.getElementById('filename').value == "") && localStorage.lastFM && 1 == 1) {
                            $("#results").css("text-align", "center");
                            $.ajax({
                                type: "GET",
                                url: "https://api.spotify.com/v1/users/" + localStorage['userID'] + "/playlists/" + localStorage['Snapster'] + "/tracks?limit=100&offset=" + localStorage["offsetNumber"],
                                headers: { 'Authorization': 'Bearer ' + access_token },
                                dataType: "json",
                                data: "formdata",
                                success: function (currentPLData) {
                                        if (localStorage["offsetNumber"] >= 95 && localStorage["offsetNumber"] <= 99) {
                                            $("#error").append("<header style='color: white; pointer-events: none;' class='songLinkClick played'>  <div> <p>Approaching Playlist Song Limit</p> <p>Party Playlists Must Be 100 (or fewer) Songs</p><p>Ask Admin To Remove Songs!</p> </div> </header>");
                                            $("#searchBoxContainer").hide();
                                        }
                                        if (localStorage["offsetNumber"] >= 100) {
                                            if ($("#results").children("header").length > 1) {
                                         //   window.location.reload();
                                            $("#results").empty();
                                            $("#albumart").empty();
                                            }
                                            $("#error").empty();
                                            $("#searchBoxContainer").hide();
                                            $("#error").append("<header title='" + currentPLData.items[0].track.album.images[0].url + "' style='color: white; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick played'>  <div> <p>Too Many Songs In Party Playlist</p> <p>Party Playlists Must Be 100 (or fewer) Songs</p> </div> </header>");
                                            $("#error").append("<center><img style='margin-top: 20%; zoom: 200%;' src='../turtle-angry.jpg' /></center>");
                                        }
                                      else if (localStorage["power_voter"] == "yes" || (localStorage["complete_access"] != "false" && localStorage["complete_access"] != false)) {
                                            $("#error").empty();
                                            $("#results").empty();
                                            $("#albumart").empty();
                                            $("#searchBoxContainer").show();
                                            $("#searchBoxContainer").fadeIn(1000);
                                            for (var i = 0; i < currentPLData.items.length; i++) {
                                                //                   $("#results").append("<header style='color: #505050; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick'> <div> <a>-</a> </div> <div> <p>" + currentPLData.items[i].track.artists[0].name + "</p> <p>" + currentPLData.items[i].track.name + "</p> </div> <div> <a>+</a> </div> </header>");
                                        if (i == 0) {
                                            try {
                                              albumArtArray[0] = currentPLData.items[0].track.album.name.toString();
                                              albumArtArray[1] = currentPLData.items[0].track.name.toString();
                                              albumArtArray[2] = currentPLData.items[0].track.artists[0].name.toString();
                                              albumArtArray[3] = currentPLData.items[0].track.album.images[0].url;
                                        $("#results").append("<header title='" + currentPLData.items[0].track.album.images[0].url + "' style='color: white; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + 0 + ", 1);' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[0].track.artists[0].name + "</p> <p>" + currentPLData.items[0].track.name + "</p> </div> <div onkeypress='increment(" + 0 + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                            }
                                            catch (exception) {
                                                // //console.log(exception);
                                                $("#results").append("<header title='" + currentPLData.items[0].track.id + "' style='color: white; pointer-events: none;' id='songLinkClick" + 0 + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + 0 + ", 1);' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[0].track.artists[0].name + "</p> <p>" + currentPLData.items[0].track.name + "</p> </div> <div onkeypress='increment(" + 0 + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                            }
                                            finally {
                                               // //console.log("Songs Have Been Loaded");
                                            }
                                        }
                                            else {
                                                try {
                                        $("#results").append("<header title='" + currentPLData.items[i].track.id + "' style='color: white; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + i + ", 1);' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[i].track.artists[0].name + "</p> <p>" + currentPLData.items[i].track.name + "</p> </div> <div onkeypress='increment(" + i + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                            }
                                            catch (exception) {
                                                // //console.log(exception);
                                            }
                                            }
                                            }
                                        }
                                        else {
                                            $("#searchBoxContainer").show();
                                            $("#searchBoxContainer").fadeIn(1000);
                                            $("#error").empty();
                                               $("#results").empty();
                                            $("#albumart").empty();
                                            for (var i = 0; i < currentPLData.items.length; i++) {
                                                //                   $("#results").append("<header style='color: #505050; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick'> <div> <a>-</a> </div> <div> <p>" + currentPLData.items[i].track.artists[0].name + "</p> <p>" + currentPLData.items[i].track.name + "</p> </div> <div> <a>+</a> </div> </header>");
                                        if (i == 0) {
                                            try {
                                        $("#results").append("<header title='" + currentPLData.items[0].track.album.images[0].url + "' style='color: white; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + 0 + ");' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[0].track.artists[0].name + "</p> <p>" + currentPLData.items[0].track.name + "</p> </div> <div onkeypress='increment(" + 0 + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                        albumArtArray[0] = currentPLData.items[0].track.album.name.toString();
                                        albumArtArray[1] = currentPLData.items[0].track.name.toString();
                                        albumArtArray[2] = currentPLData.items[0].track.artists[0].name.toString();
                                        albumArtArray[3] = currentPLData.items[0].track.album.images[0].url;
                                            }
                                            catch (exception) {
                                                // //console.log(exception);
                                                $("#results").append("<header title='" + currentPLData.items[0].track.id + "' style='color: white; pointer-events: none;' id='songLinkClick" + 0 + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + 0 + ");' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[0].track.artists[0].name + "</p> <p>" + currentPLData.items[0].track.name + "</p> </div> <div onkeypress='increment(" + 0 + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                                albumArtArray[0] = currentPLData.items[0].track.album.name.toString();
                                                albumArtArray[1] = currentPLData.items[0].track.name.toString();
                                                albumArtArray[2] = currentPLData.items[0].track.artists[0].name.toString();
                                            }
                                            finally {
						    votes();
                                               // //console.log("Songs Have Been Loaded");
                                            }
                                        }
                                            else {
                                                try {
                                        $("#results").append("<header title='" + currentPLData.items[i].track.id + "' style='color: white; pointer-events: none;' id='songLinkClick" + i + "'" + "class='songLinkClick played'> <div onkeypress='decrement(" + i + ");' class='voteBtn'> <a>-</a> </div> <div> <p>" + currentPLData.items[i].track.artists[0].name + "</p> <p>" + currentPLData.items[i].track.name + "</p> </div> <div onkeypress='increment(" + i + ", 0);' class='voteBtn'> <a>+</a> </div> </header>");
                                            }
                                            catch (exception) {
                                                // //console.log(exception);
                                            }
                                            }
                                            }
                                        }
                                    if ($("#results").children("header").length > 1) {
                                         document.getElementById("songLinkClick" + 0).style.color = "black";
                                         $("#songLinkClick0").attr("name", "current");
                                         $("[name='current']").css("id")
                                         $("[name='current']").children("div")[0].style.display = "none";
                                         $("[name='current']").children("div")[2].style.display = "none";
                                         /*$("#songLinkClick1").children("div")[0].style.display = "none";
                                         $("#songLinkClick1").children("div")[2].style.display = "none";*/
                                         $("#albumart").append("<div class='firstAA'><img style='display: inline-block; height: 244px;' src=" + $('[name="current"]')[0].attributes[0].value + " style=''/><div class='secondAA'><h1 class='albumInfo'>" + albumArtArray[2] + "</h1><h1 class='albumInfo'>" + albumArtArray[1] + "</h1><h1 class='albumInfo'>" + albumArtArray[0] + "</h1><h1 class='albumInfo'></div></div>");
                                      //  $("#all").fadeIn(1000);
                                    }
                                  
                                   }

                            });
                            playlists = [];
                            currentTracks = [];
                        }
                    }
                }
    }
  }
  });
